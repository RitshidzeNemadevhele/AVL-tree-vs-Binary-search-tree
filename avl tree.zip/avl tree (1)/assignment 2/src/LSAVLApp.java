import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

/**
 * @author ritshidze nemadevhele
 *
 */



public class LSAVLApp {

	public static int count = 0;        //insert count
	public static int counter = 0;      //find count
	public static String time = null;
	public static String area = null;
	public static String date = null;
	public static String stage = null;

	public static  Scanner f = null;



	/**
	 * @param opens and read the file 
	 * @throws FileNotFoundException  is thrown during the failed attempt to open file
	 */
	public static void readFile(String fileName) throws FileNotFoundException
	{
		f = new Scanner(new File(fileName));
	}

   

	/**
	 * uses the for loop to read every line as Strings from the file and store them in word
	 * split the lines and store them in data
	 * insert the areas into the AVL
	 * use the find method to get all areas and print them
	 * this methods is only executed when there is no parameters provided
	 */
	@SuppressWarnings("static-access")
	public static void printAllAreas()
	{ 
        LSAVLApp obj1 = new  LSAVLApp();
		for (int i = 0 ; i < 2976 ; i++)
		{  
			String word = f.nextLine();


			String[] data = word.split("_");
			obj1.Insert(data[2].substring(3));
			//string areas =data[2].substring(3);
			System.out.println(obj1.Find(data[2].substring(3)).iterm);
		   
		 
		}

	}
	
	
	

	/**
	 * @parameter s takes load shedding stage from the user
	 * @param d takes the date from the user
	 * @param startTime takes the starting time from the user
	 * used for loop to read all lines from the file as strings
	 * split the lines and store them in words
	 * the insert stage , date , time , areas on the binary search tree using insert method
	 * compare if the parameter matches the data stored in AVL 
	 * use findNode method to print out the areas if the match is found
	 * print areas not found if there is no match
	 */
	
	  @SuppressWarnings("static-access")
	public static void prinAreas(String s , String d , String startTime)
		{  LSAVLApp obj2 = new LSAVLApp();
		
		for (int i = 0 ; i < 2976 ; i++)
		{  
			String word = f.nextLine();
			String[] words = word.split("_");
           // String period = words[0]+" "+words[1]+" "+words[2].substring(0,2) ;
            String area = words[2].substring(3) ;

			obj2.Insert( area );

			if(words[0].equals(s) && words[1].contentEquals(d) && words[2].substring(0,2).contentEquals(startTime))
			{  
				System.out.println(obj2.Find(area).iterm);
			
				System.exit(0);
			}

		}
		System.out.println("areas not found!");   

		  
		
		}
	  
	
	  /**
		 * this method write all the output into the file named output3.txt
		 */
		public static int opcount= 0;
		public void opcounter(){

			//Create the file
			try{
				File file = new File("output3.txt");
				if (file.createNewFile())
				{
					//Write Content
					FileWriter writer = new FileWriter(file);
					writer.write("There are "+opcount+" Comparison Operations.");
					writer.close();

				} else {
					System.out.println("File already exists.");
				}

			}catch(Exception e){
				System.out.println("Error occured");
			}
		}

	  
		/**
		 * create node as inner class
		 * and create the Nodes
		 *
		 */

	class Node
	{
		public int key;
		public String iterm;
		public Node leftChild;
		public Node rightChild;
        public int height;

		public Node( String iterm , Node leftChild ,Node rightChild)
		{  
			this.iterm=iterm;
			this.leftChild=leftChild;
			this.rightChild=rightChild;
			height =0 ;
		}

	}


	static Node root;

	/**
	 * 
	 *this method return the height of the tree
	 */
	  public int height ( Node node )
	   {
	      if (node != null)
	         return node.height;
	      return -1;
	   }
	  
	 
	  public int balanceFactor ( Node node )
	   {
	      return height (node.rightChild) - height (node.leftChild);
	   }
	   
	   public void fixHeight ( Node node )
	   {
	      node.height = Math.max (height (node.leftChild), height (node.rightChild)) + 1;
	   }
	   
	   /**
	    * this method rotate the tree using rightRotation
	    */
	  public Node rotateRight ( Node p )
	   {
	      Node q = p.leftChild;
	      p.leftChild = q.rightChild;
	      q.rightChild = p;
	      fixHeight (p);
	      fixHeight (q);
	      return q;
	   }

	  /**
	   * this method rotate the tree using leftTree rotation
	   */
	  public Node rotateLeft ( Node q )
	   {
	      Node p = q.rightChild;
	      q.rightChild = p.leftChild;
	      p.leftChild = q;
	      fixHeight (q);
	      fixHeight (p);
	      return p;
	   }
	   
	  
	  
	  /**
	   * this is the method for balancing the tree 
	   */
	  
	   public Node balance ( Node p )
	   {
	      fixHeight (p);
	      if (balanceFactor (p) == 2)
	      {
	         if (balanceFactor (p.rightChild) < 0)
	            p.rightChild = rotateRight (p.rightChild);
	         return rotateLeft (p);
	      }
	      if (balanceFactor (p) == -2)
	      {
	         if (balanceFactor (p.leftChild) > 0)
	            p.leftChild = rotateLeft (p.leftChild);
	         return rotateRight (p);
	      }
	      return p;
	   } 
	  
	   
	   

		/**
		 * add nodes into the tree
		 * @param key the key that represent position of nodes stored 
		 * @param iterm the nodes we are adding to AVL
		 */
	   public void Insert ( String d )
	   {
	      root = insert (d, root);
	   }
	   public Node insert ( String d, Node node )
	   {
	      if (node == null)
	         return new Node (d, null, null);
	      if (d.compareTo (node.iterm) <= 0)
	         node.leftChild = insert (d, node.leftChild);
	      else
	         node.rightChild = insert (d, node.rightChild);
	      return balance (node);
	   }
	   

		/**
		 * @param key
		 * @return  the area for matching stage date and time provided by user 
		 */
	   public static Node Find ( String d )
	   {
	      if (root == null)
	         return null;
	      else
	         return Find (d, root);
	   }
	   public static Node Find ( String d, Node node )
	   {
	      if (d.compareTo (node.iterm) == 0) 
	      { 
	    	  return node;}
	      else if (d.compareTo (node.iterm) < 0)
	      {   
	         return (node.leftChild == null) ? null : Find (d, node.leftChild);
	      }
	      else
	   {    
	    	  return (node.rightChild == null) ? null : Find (d, node.rightChild);
	   }
	     
	   }	   
	
	   
	   
	   public void treeOrder ()
	   {
	      treeOrder (root, 0);
	   }
	   public void treeOrder ( Node node, int level )
	   {
	      if (node != null)
	      {
	         for ( int i=0; i<level; i++ )
	         System.out.println (node.iterm);
	         treeOrder (node.leftChild, level+1);
	         treeOrder (node.rightChild, level+1);//
	      }
	   }
	   
	
	   

		/**
		 * invoke method printAllAreas() if the is no parameters provided
		 *  invoke method printAreas( stg , day , startTime) if the user provide parameters
		 *  and also print number of comparisons
		 *  
		 */
	   
	   public static void main(String[] args) {

			try {
				readFile("Load_Shedding_All_Areas_Schedule_and_Map.clean.final.txt");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			@SuppressWarnings("resource")
			Scanner input = new Scanner(System.in);

			String userInput = input.nextLine();
			String[] inputList = userInput.split(" ");



			if (userInput.isEmpty()) { 
				printAllAreas();
			}
			else{
				String stg = inputList[0].trim();
				String day = inputList[1].trim();
				String startTime = inputList[2].trim();

				prinAreas(stg, day, startTime);

			}

		
	   }
}