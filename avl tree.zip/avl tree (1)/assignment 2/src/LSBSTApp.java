import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;




/**
 * @author ritshidze nemadevhele
 *
 */
public class LSBSTApp {

	public static String time = null;
	public static String area = null;
	public static String date = null;
	public static String stage = null;

	public static  Scanner f = null;



	/**
	 * @param opens and read the file 
	 * @throws FileNotFoundException  is thrown during the failed attempt to open file
	 */

	public static void readFile(String fileName) throws FileNotFoundException
	{
		f = new Scanner(new File(fileName));
	}



	/**
	 * uses the foe loop to read every line as Strings from the file and store them in word
	 * split the lines and store them in data
	 * insert the areas into the binary search tree
	 * use the find method to get all areas and print them
	 * this methods is only executed when there is no parameters provided
	 */
	public static void printAllAreas()
	{    
		LSBSTApp obj = new LSBSTApp();
		//List<String> arraylis = null;
		for (int i = 0 ; i < 2976 ; i++)
		{  
			String word = f.nextLine();

			//String[] words = word.split("[_ ]");
			String[] data = word.split("_");//[2].split(" ");
			//System.out.println("Time " + data[2].substring(0, 2).trim() + " Area " + data[2].substring(3).trim());
			obj.insert(i , data[2].substring(3));
			System.out.println(obj.findNode(i).iterm);
		}
		//	System.out.println(obj.findNode(i));


	}


	/**
	 * @parameter s takes load shedding stage from the user
	 * @param d takes the date from the user
	 * @param startTime takes the starting time from the user
	 * used for loop to read all lines from the file as strings
	 * split the lines and store them in words
	 * the insert stage , date , time , areas on the binary search tree using insert method
	 * compare if the parameter matches the data stored in BST 
	 * use findNode method to print out the areas if the match is found
	 * print areas not found if there is no match
	 */
	public static void prinAreas(String s , String d , String startTime)
	{    LSBSTApp obj = new LSBSTApp();

	for (int i = 0 ; i < 2976 ; i++)
	{  
		String word = f.nextLine();
		String[] words = word.split("_");


		obj.insert(i , words[0] + words[1] + words[2].substring(0,2) + words[2].substring(2));

		if(words[0].equals(s) && words[1].contentEquals(d) && words[2].substring(0,2).contentEquals(startTime))
		{  
			System.out.println(obj.findNode(i).iterm.substring(5));
			///System.out.println(words[2].substring(3));
			System.exit(0);
		}

	}
	System.out.println("areas not found!");   

	}



	/**
	 * this method write all the output into the file named output3.txt
	 */
	public static int opcount= 0;
	public void opcounter(){

		//Create the file
		try{
			File file = new File("output1.txt");
			if (file.createNewFile())
			{
				//Write Content
				FileWriter writer = new FileWriter(file);
				writer.write("There are "+opcount+" Comparison Operations.");
				writer.close();

			} else {
				System.out.println("File already exists.");
			}

		}catch(Exception e){
			System.out.println("Error occured");
		}
	}

	

	/**
	 * create node as inner class
	 * and create the Nodes
	 *
	 */

	class Node
	{
		public int key;
		public String iterm;
		public Node leftChild;
		public Node rightChild;


		public Node(int key, String iterm)
		{
			this.key=key;
			this.iterm=iterm;			
		}

		public String returnnIterm()
		{ 
			return iterm; 
		}


	}


	Node root;


	/**
	 * add nodes into the tree
	 * @param key the key that represent position of nodes stored 
	 * @param iterm the nodes we are adding to BST
	 */
	public void insert ( int key, String iterm ) {

		Node newNode =  new  Node(key , iterm);
		if(root == null){

			root   = newNode;   //if tree = empty, add new node to root

		}
		else {

			Node centreNode = root;

			Node parentNode;

			while(true){
				parentNode = centreNode;

				if (key < centreNode.key) {

					centreNode = centreNode.leftChild;

					if (centreNode == null) {

						parentNode.leftChild = new Node(key, iterm);;
						return;
					}

				}
				else {

					centreNode = centreNode.rightChild;

					if (centreNode == null) {

						parentNode.rightChild = newNode;;
						return;

					}

				}

			} 
		} 
	}




	/**
	 * @param centreNode
	 */
	public void inOrderTraversalTree(Node centreNode){

		if (centreNode != null) {

			inOrderTraversalTree(centreNode.leftChild);

			System.out.println(centreNode);

			inOrderTraversalTree(centreNode.rightChild);

		}

	}


	/**
	 * @param key
	 * @return  the area for matching stage date and time provided by user
	 */





	public Node findNode(int key){

		Node centreNode = root; while(centreNode.key != key){

			if(key < centreNode.key) { centreNode = centreNode.leftChild;

			}

			else{

				centreNode = centreNode.rightChild;



			}

			if (centreNode == null){

				return null;

			}

		} return centreNode;

	}


	//close the load shedding file
	public static void close()
	{f.close();}



	/**
	 * invoke method printAllAreas() if the is no parameters provided
	 *  invoke method printAreas( stg , day , startTime) if the user provide parameters
	 *  and also print number of comparisons
	 *  
	 */
	public static void main(String[] args) {

		try {
			readFile("Load_Shedding_All_Areas_Schedule_and_Map.clean.final.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);

		String userInput = input.nextLine();
		String[] inputList = userInput.split(" ");

		if (userInput.isEmpty()) { 
			printAllAreas();
		}
		else{
			String stg = inputList[0].trim();
			String day = inputList[1].trim();
			String startTime = inputList[2].trim();

			prinAreas(stg, day, startTime);
		}

		close();
	}


}


